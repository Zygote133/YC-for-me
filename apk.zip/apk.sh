tmp="/data/local/tmp"
APK_DIR="/storage/emulated/0/Zygote133/安装包"
zygote="/storage/emulated/0/Zygote133"
selinux_status=$(getenforce)
uninstallapk=("$Package_name" "icu.nullptr.applistdetector" "com.zhenxi.hunter" "io.github.huskydg.memorydetector" "io.github.vvb2060.mahoshojo" "com.tsng.pzyhrx.kka" "com.byxiaorun.detector" "icu.nullptr.nativetest" "me.garfieldhan.holmes" "luna.safe.luna" "com.reveny.nativecheck" "com.youhu.laifu" "com.tsng.dyhhvf" "com.tsng.hidemyapplist")
Hideapp='{"configVersion":90,"detailLog":false,"maxLogSize":512,"forceMountData":true,"templates":{"Made By Zygote133 W":{"isWhitelist":true,"appList":["com.tencent.mm","com.tencent.mobileqq","com.facebook.katana","com.twitter.android","com.google.android.gsf","com.google.android.gms","com.android.vending","com.mfcloudcalculate.networkdisk","com.adb.useroperation","com.baidu.searchbox","com.baidu.searchbox.lite","com.baidu.input_mi","com.baidu.netdisk","com.miui.notes","com.clover.daysmatter","com.ss.android.auto","com.ctid.open","com.android.email","com.ss.android.ugc.aweme","com.ss.android.ugc.aweme.lite","com.larus.nova","com.aitutor.hippo","com.baidu.tzeditor","me.ele","com.ss.android.lark","com.autonavi.minimap","cn.xiaofn.article","com.yuyao.gaokao","com.xproducer.yingshiai","com.huaxiaozhu.rider","com.chan.hx","com.hunhepan.search","com.truestudio.guitartuner","com.jxbz.jisbsq","com.miui.calculator","com.jacey.camera.detector","com.kd.jx","com.quark.browser","com.smile.gifmaker","com.kuaishou.nebula","com.kwai.videoeditor","com.miui.cleanmaster","com.sankuai.meituan.takeoutnew","com.sankuai.meituan","meiyi.com.ptupintukoutu.zhaopianbianji.quanneng","com.jdd.motorfans","com.fsnaniejiakao.com","com.miui.newhome","com.xunmeng.pinduoduo","com.miui.screenrecorder","com.luna.music","com.mipay.wallet","com.gorgeous.lite","com.farplace.qingzhuo","com.miui.virtualsim","com.miui.thirdappassistant","com.android.calendar","com.android.deskclock","com.taobao.taobao","com.tencent.wemeet.app","com.tencent.qqlive","com.singularity.tiangong","com.miui.weather2","com.MobileTicket","com.duokan.phone.remotecontroller","cn.rxxlong.translate","com.ss.android.article.video","com.xiaomi.mibrain.speech","com.xiaomi.scanner","com.mfashiongallery.emag","com.miui.huanji","com.xingin.xhs","com.xiaomi.shop","com.xiaomi.vipaccount","com.miui.video","cn.wps.moffice_eng.xiaomi.lite","com.miui.mediaeditor","com.xiaomi.youpin","com.miui.newmidrive","com.mi.health","ctrip.android.view","com.xt.retouch","com.iflytek.inputmethod.miui","com.xunlei.downloadprovider","com.zhishoutui.app","com.eg.android.AlipayGphone","com.ct.client","com.baidu.carlife.xiaomi","com.miui.compass","com.icbc","com.tencent.qqmusic","com.tencent.androidqqmail","se.perigee.android.seven","cn.wps.moffice_eng","com.blackshark.market","com.blackshark.store","com.xiaomi.ab","com.miHoYo.hkrpg","com.tencent.tmgp.pubgmhd","com.tencent.tmgp.dfm"]}},"scope":{"com.tencent.mf.uam":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.tencent.tmgp.pubgmhd":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":["com.tencent.gamehelper.pg"]},"com.tencent.jkchess":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.tencent.ig":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"io.github.vvb2060.mahoshojo":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"icu.nullptr.applistdetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":[],"extraAppList":[]},"com.godevelopers.OprekCek":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":[],"extraAppList":[]},"com.byxiaorun.detector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"io.github.huskydg.memorydetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.alibaba.android.rimet":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":[],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.tencent.tmgp.sgame":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.cmri.universalapp":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":[],"extraAppList":[]},"com.lptiyu.tanke":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":[],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.pubg.imobile":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.rekoo.pubgm":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.vng.pubgmobile":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.pubg.krmobile":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"me.garfieldhan.holmes":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.henrikherzig.playintegritychecker":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.tencent.gamehelper.pg":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":["com.tencent.tmgp.pubgmhd"]},"io.github.a13e300.dsf_detector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"io.github.vvb2060.keyattestation":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.zhenxi.hunter":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"icu.nullptr.nativetest":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.youhu.laifu":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.tsng.applistdetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"io.github.vvb2060.magiskdetector":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"luna.safe.luna":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.smile.gifmaker":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.tencent.tmgp.cod":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.reveny.nativecheck":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"io.liankong.riskdetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.miHoYo.hkrpg":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]},"com.tencent.tmgp.dfm":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["Made By Zygote133 W"],"extraAppList":[]}}}"'
Old_hideapp="/data/user/0/com.tsng.pzyhrx.hma/files/config.json"
if [ "$selinux_status" == "Enforcing" ];then
setenforce 0
echo -e "SELinux 已临时关闭"
else
echo -e "SELinux 临时关闭失败"
fi
for i in $(pm list package -3); do
    apk=${i/package:/}
    found=0
    for pkg in "${uninstallapk[@]}"; do
        if [[ "$apk" == "$pkg" ]]; then
            found=1
            break
        fi
    done
    if [[ $found -eq 1 ]]; then
        pm uninstall "$apk" >/dev/null 2>&1
    fi
    echo "-没找到对应包名$apk"
    clear
done
echo "安装软件"

for apk in "$APK_DIR"/*.apk; do
    if [ -f "$apk" ]; then
        cp "$apk" "$tmp/"
    else
        echo "$apk 不存在或者不是文件"
    fi
done

for apk in "$tmp"/*.apk; do
    if [ -f "$apk" ]; then
        echo "正在安装: $apk"
        if pm install "$apk"; then
            echo "$apk 安装成功"
        else
            echo "$apk 安装失败"
        fi
        rm "$apk"
    else
        echo "$apk 不存在或者不是文件"
    fi
done

am start com.tsng.pzyhrx.hma/icu.nullptr.hidemyapplist.ui.activity.MainActivity
sleep 2
am start bin.mt.plus.canary/bin.mt.plus.Main
sleep 0.3
echo "$Hideapp" > "$Old_hideapp"
sleep 0.3

echo "隐藏应用列表配置成功!"
sleep 0.3