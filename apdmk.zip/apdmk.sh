MODULE_DIR="/storage/emulated/0/Zygote133/模块"
zygote="/storage/emulated/0/Zygote133"
Keyxml='<?xml version="1.0"?>
<AndroidAttestation>
<NumberOfKeyboxes>1</NumberOfKeyboxes>
<Keybox DeviceID="47"><Key algorithm="ecdsa"><PrivateKey format="pem">-----BEGIN EC PRIVATE KEY-----
MHcCAQEEICTEQDmch9VxGBk70v5xGcahrY53L0fJuZ3ERaCTpKSdoAoGCCqGSM49
AwEHoUQDQgAE4E75+2STxJzAa4+V2Zg2PgyE+q4Lob5tAqRu8WgCkuIkesb543zq
9vf4kiN8YIjNununjMUEdIqa1N0LYL0gKw==
-----END EC PRIVATE KEY-----
</PrivateKey><CertificateChain><NumberOfCertificates>3</NumberOfCertificates><Certificate format="pem">-----BEGIN CERTIFICATE-----
MIIB9TCCAXqgAwIBAgIRAOU0h+W44ugqtEsK/1dAgQMwCgYIKoZIzj0EAwIwOTEM
MAoGA1UEDAwDVEVFMSkwJwYDVQQFEyA1MjE3MGJiNmMxYmU5OThlOTFhYWMzMmFk
MTZhY2M3MjAeFw0yMTA2MTYxOTMzMDdaFw0zMTA2MTQxOTMzMDdaMDkxDDAKBgNV
BAwMA1RFRTEpMCcGA1UEBRMgZGRlMjIzNzE0ODA3ODNiNTBhNWE5MGVkYjAwNTUz
ZTIwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAATgTvn7ZJPEnMBrj5XZmDY+DIT6
rguhvm0CpG7xaAKS4iR6xvnjfOr29/iSI3xgiM26e6eMxQR0iprU3QtgvSAro2Mw
YTAdBgNVHQ4EFgQUIhcrjJQVJe5JvseBnreCSDCi7UYwHwYDVR0jBBgwFoAUwdWK
gsJzPZ5OTL0D70MhBF4rHBYwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC
AgQwCgYIKoZIzj0EAwIDaQAwZgIxANILtGNSlmc35fo5gG9fmAMSEk4+R+6h0Tzj
w5F5M/MRt7j7qnXQ8HgYcqD+wFSaNgIxAIPQfQAUXbwJb7MISD7fKsBkf8dA9Yk8
C8B3t0g8BtQo7zweDnMoiLHt6jdYx1E9qQ==
-----END CERTIFICATE-----
</Certificate><Certificate format="pem">-----BEGIN CERTIFICATE-----
MIIDkzCCAXugAwIBAgIQRTbwPpRAKqnIBjCmn0ePiDANBgkqhkiG9w0BAQsFADAb
MRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MB4XDTIxMDYxNjE5Mjk0OVoXDTMx
MDYxNDE5Mjk0OVowOTEMMAoGA1UEDAwDVEVFMSkwJwYDVQQFEyA1MjE3MGJiNmMx
YmU5OThlOTFhYWMzMmFkMTZhY2M3MjB2MBAGByqGSM49AgEGBSuBBAAiA2IABPBg
LElUT/XHzsjHI54Fa4Lnz8BZdUa7UYrCX1eWFdjnHjw1UnI79BuaDIgvtGL32cEl
GBeyxyKHGSk04DLkJZk+1kY734Ix6jO8EkJqzHIfaWWsIv5vzk6d62jxK/YnWaNj
MGEwHQYDVR0OBBYEFMHVioLCcz2eTky9A+9DIQReKxwWMB8GA1UdIwQYMBaAFDZh
4QB8iAUJUYtEbEf/GkzJ6k8SMA8GA1UdEwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQD
AgIEMA0GCSqGSIb3DQEBCwUAA4ICAQCYlyyM+iVGv04jSDsciYrUcmlPCiYjLQyS
cO06vAJnm1+0b+B5spai4ZmN7pXSyJxHQ8BMUOWQWCbjxP/y+PQlS5gxxu1pVx7s
gsQvt9//pw0d0irodAH0wVwZiopnEjQ9JNup+Gg6gIl4BbjamwEoy6FvlZqjSe66
2KqQ0g8OG4tcwTpghZ24ujUE8k3K2I7JAIIIh5jODDk9nL5FdUuLCYDhECaVoIOK
gR9nCWUUKHMw5AU3foV5LDZ6T8Je9x1I4Qgc4n3uEkEc+c0CsggHintWyZzfrqDj
8goNKgMm1FyRheiIiMRmiz1VHYP0F1tDg40AnS8L6Est45JfNNSUOGmV38wOhWkJ
wC1a+sexL/7gPHVEGYv2fsxaAmVbPT9rH8olK7e2rc0rznHQc47GfyRO8rKHWvmY
gMld8c3FbnJpgPfQ0AXS7AtOPa5jU37mn8Hce9Odv4itrnza+hj5+Qg+FZVBS88D
oNF79E6nw0CHSHBtQYWI9ARXlyV0H65ukOOcWMHpHi6GY3zhtd1XrAQO9KfqsmAI
GnisR+ZEA9kZQ//d0QMRWd01EMgB38LQaJg7MCcrzf/dSkdAFWjWiB3gB+eyXqf3
kbbZIy3i7PHox4gi0bz4HqZU8cXI5uV7/k+n7Ks6Z8Ju6Mk8DMPUFN4K2ERxKUhO
vbzkHM9/sQ==
-----END CERTIFICATE-----
</Certificate><Certificate format="pem">-----BEGIN CERTIFICATE-----
MIIFHDCCAwSgAwIBAgIJANUP8luj8tazMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNV
BAUTEGY5MjAwOWU4NTNiNmIwNDUwHhcNMTkxMTIyMjAzNzU4WhcNMzQxMTE4MjAz
NzU4WjAbMRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MIICIjANBgkqhkiG9w0B
AQEFAAOCAg8AMIICCgKCAgEAr7bHgiuxpwHsK7Qui8xUFmOr75gvMsd/dTEDDJdS
Sxtf6An7xyqpRR90PL2abxM1dEqlXnf2tqw1Ne4Xwl5jlRfdnJLmN0pTy/4lj4/7
tv0Sk3iiKkypnEUtR6WfMgH0QZfKHM1+di+y9TFRtv6y//0rb+T+W8a9nsNL/ggj
nar86461qO0rOs2cXjp3kOG1FEJ5MVmFmBGtnrKpa73XpXyTqRxB/M0n1n/W9nGq
C4FSYa04T6N5RIZGBN2z2MT5IKGbFlbC8UrW0DxW7AYImQQcHtGl/m00QLVWutHQ
oVJYnFPlXTcHYvASLu+RhhsbDmxMgJJ0mcDpvsC4PjvB+TxywElgS70vE0XmLD+O
JtvsBslHZvPBKCOdT0MS+tgSOIfga+z1Z1g7+DVagf7quvmag8jfPioyKvxnK/Eg
sTUVi2ghzq8wm27ud/mIM7AY2qEORR8Go3TVB4HzWQgpZrt3i5MIlCaY504LzSRi
igHCzAPlHws+W0rB5N+er5/2pJKnfBSDiCiFAVtCLOZ7gLiMm0jhO2B6tUXHI/+M
RPjy02i59lINMRRev56GKtcd9qO/0kUJWdZTdA2XoS82ixPvZtXQpUpuL12ab+9E
aDK8Z4RHJYYfCT3Q5vNAXaiWQ+8PTWm2QgBR/bkwSWc+NpUFgNPN9PvQi8WEg5Um
AGMCAwEAAaNjMGEwHQYDVR0OBBYEFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMB8GA1Ud
IwQYMBaAFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMA8GA1UdEwEB/wQFMAMBAf8wDgYD
VR0PAQH/BAQDAgIEMA0GCSqGSIb3DQEBCwUAA4ICAQBOMaBc8oumXb2voc7XCWnu
XKhBBK3e2KMGz39t7lA3XXRe2ZLLAkLM5y3J7tURkf5a1SutfdOyXAmeE6SRo83U
h6WszodmMkxK5GM4JGrnt4pBisu5igXEydaW7qq2CdC6DOGjG+mEkN8/TA6p3cno
L/sPyz6evdjLlSeJ8rFBH6xWyIZCbrcpYEJzXaUOEaxxXxgYz5/cTiVKN2M1G2ok
QBUIYSY6bjEL4aUN5cfo7ogP3UvliEo3Eo0YgwuzR2v0KR6C1cZqZJSTnghIC/vA
D32KdNQ+c3N+vl2OTsUVMC1GiWkngNx1OO1+kXW+YTnnTUOtOIswUP/Vqd5SYgAI
mMAfY8U9/iIgkQj6T2W6FsScy94IN9fFhE1UtzmLoBIuUFsVXJMTz+Jucth+IqoW
Fua9v1R93/k98p41pjtFX+H8DslVgfP097vju4KDlqN64xV1grw3ZLl4CiOe/A91
oeLm2UHOq6wn3esB4r2EIQKb6jTVGu5sYCcdWpXr0AUVqcABPdgL+H7qJguBw09o
jm6xNIrw2OocrDKsudk/okr/AwqEyPKw9WnMlQgLIKw1rODG2NvU9oR3GVGdMkUB
ZutL8VuFkERQGt6vQ2OCw0sV47VMkuYbacK/xyZFiRcrPJPb41zgbQj9XAEyLKCH
ex0SdDrx+tWUDqG8At2JHA==
-----END CERTIFICATE-----
</Certificate></CertificateChain></Key><Key algorithm="rsa"><PrivateKey format="pem">-----BEGIN RSA PRIVATE KEY-----
MIIG5AIBAAKCAYEAzyC3t1BDzjRexng92feE2u6xj5fjRd0FK2FlJxh+y31GDefh
TngpZSq3zivE9agM9+C9+blJzB9LfyrfzJ7510Sv6LuC/W8p1xS0jppHqJH4Gf6c
E7xADyvwVtI3ItmakHdOo+RhZkvThV2KiqgopuQTK63vn1jlvG1Y//RPM7cuD4Tz
IoONwpkigWynYI5vFILnenFLUG+NsAx2oS2VJKRrSQiGblU2mt969ccOPxflw4Qn
RBeU8Qf6d1In2wccrorKIgmzU7tupJ4VlRF/iQbabsOALU1fEbKmbrJQflcfdc3I
VGQqIt0Tsqa7vBIZNpBLdorGI0BEM1E9JH6uKe8K3F5ybWNi6oaHX951S+oKfTLG
BLkElXqAilGe7KWtx+Oaq5w3VlvLwdeYSA0qciHrK2VKOMtZVtPgM7FTxi9GkBhL
wMORmsmdWaXv86+AA8w4fDqYZ71h9osIPUMvLNj4uOTdjM7CnecZsvBxzmhBPlIe
Bv0ZyPmMz/p+ilc9AgMBAAECggGAMSehkdZxkQEqsM0eWJj+JXraFqrEG/Nc47Ok
bsfIZ4BeXLR36shngoPFxR7sCiSMl1L1ossPMWsH3rENFaFwx16cpI3Dg2ObOVjH
lMQWV3H0wC6FWcWmKjOSQPh4b0PXA4vc1NZBKya5lv/g/hD0PM8JoacQo+9T7gjB
Q1T2at6BBtvVW45+2PzAjJh9jFOhFuwOBSfX6MnghTQf/xYzO9PtRhLI3GxKniyF
IMjRn7WLKIA3VViHV0A+d4y+uqMQBQQI7RsJsetxumtK3Om3wkLLTos+AT5blipc
cXPCicHMTTBO2K6wghL3yYCRQYN7KSnZ0JorG/BGuNOfwxjfGjMjAcpg3Kz3J6yf
hCe6EmrucGdBgVgDCpTbdvFHZPSOaUfC8q/RR3uMWVcRL/pW1QBsAL0LYr85le8r
UUnnXOYJwcI+HfoHmJZR/uJZu5HQGQGk2BkxBJD/llOjFsDQe5gzN5jFtNRF7UHA
wUDYoxn4HWaZHOBwQshvxd69mqbhAoHBAPL5C1gdenPXDu+FtgoiAqs0Ky8OHR3w
vUUgxnny2cnvxehN9cnupuUf33Zj5pYi8pLZV6Qom83jdi39nHirx+GdQazx26GH
gt5sKd8l2+y8nu7fO5+LxqSTHxcmhPRBNYDr29Zgs6oIN23beLLaFsrW9nERY5Z6
FGw4hst757/3ZrsMh3iq4wZ85EtKsTf+eXoZP8XdDUMv7D7usMr/FuUo/qK7xqgy
Wqud24GOkxLdSYGvAN2r8lfO27MNE9/JeQKBwQDaO618tc8nV4yYfNbn+TRYQjk+
Ho5seB9tsjVaUXqpu3E0rAQ7uQcfEQlM5WkWhACwX0E1Y8RH17dN9VHIonR2I8b2
4NWOjH38RbNtRyuqHnoZ2FLdxP7S/3okl+EIJTVnTvqXXSA7+XKz0t3Gjc57zTxP
H7zUWGhFAiMIW/49iIAWsBZhNjOUx0X3KKdepsbKuEHyS40OXUu5Cf2A2dvudruP
F1c5gt1HqymRkFJQgszR6HNnNqKO3YTY8JXqjuUCgcBGG3IYhLj2f9FBb5VtKw8W
E0F6nFnub65NKf3a5iXNTLAQLZ6EG6ZwalfyMzUvkPnpQWk2Zrk+GSnab1kcwIQ2
J0fx/P9ghldOkmsqhiQFFQ/O4P61NIGmrwTDi0vFpqMnheay3sg4gZJs0mzrPl5h
PNFzIo9XtfX6m/zY7fGaxGoSArV8LeK/1n2Q9AZan8SxZGOwVe4jusoyBnFgwWX7
zW5byk6x7YWYCz5xDZCGWu+Aydw4GgsdJwThjx5y7hECgcEApT9VIb6lipvPmVPG
g0b/bOlQYQpQPDBFVBICNk7GPCn0EbdDSVnU26BR04lPJr5zqxmlzeCqqt/cLErb
T7o7x41VxnD/JH6bk1/P+qpOlPWY7WMRdF4Luwe6nGTo//r00jJKrDzXALLlOOcu
CYAtXy9MQHm+yWfcJIz2rAjEniFzJDrX52pcaobuIrYE7jYJB024mdi9iaf5g7bd
3yiYUZxUb4h0Atdl6TPhORj4S4CPyU5jvD7xno58XqzmSANFAoHBANZ7CJa/taHw
7lenY2xxZbo1jzS8OF7WuYxN4a4jS0wYcEsRIiBMvlqN9TMgyphMtnZgEYC9CgRR
mylfiNUdxedc3FKKkl/7vYLTbOsxuFa3NfpA7IXtCUPfK/kG9cLI8s+C1DV9Kz8X
NmjLcv1bvQCFbD5nuK1/dRTQkjD7/ZiVAXvweIXYwcivriD59AR09rTRV0fEz9Fh
esJcjpHbJzwdsEwVZUBiBMHnvLEw/uLVCU0y8wCfUFGJ39li91y9QA==
-----END RSA PRIVATE KEY-----
</PrivateKey><CertificateChain><NumberOfCertificates>3</NumberOfCertificates><Certificate format="pem">-----BEGIN CERTIFICATE-----
MIIE3zCCAsegAwIBAgIQYWEEesVTnYAjzkCdv1RPhDANBgkqhkiG9w0BAQsFADA5
MQwwCgYDVQQMDANURUUxKTAnBgNVBAUTIDUyMTcwYmI2YzFiZTk5OGU5MWFhYzMy
YWQxNmFjYzcyMB4XDTIxMDYxNjE5MzMwNloXDTMxMDYxNDE5MzMwNlowOTEMMAoG
A1UEDAwDVEVFMSkwJwYDVQQFEyBkZGUyMjM3MTQ4MDc4M2I1MGE1YTkwZWRiMDA1
NTNlMjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAM8gt7dQQ840XsZ4
Pdn3hNrusY+X40XdBSthZScYfst9Rg3n4U54KWUqt84rxPWoDPfgvfm5ScwfS38q
38ye+ddEr+i7gv1vKdcUtI6aR6iR+Bn+nBO8QA8r8FbSNyLZmpB3TqPkYWZL04Vd
ioqoKKbkEyut759Y5bxtWP/0TzO3Lg+E8yKDjcKZIoFsp2CObxSC53pxS1BvjbAM
dqEtlSSka0kIhm5VNprfevXHDj8X5cOEJ0QXlPEH+ndSJ9sHHK6KyiIJs1O7bqSe
FZURf4kG2m7DgC1NXxGypm6yUH5XH3XNyFRkKiLdE7Kmu7wSGTaQS3aKxiNARDNR
PSR+rinvCtxecm1jYuqGh1/edUvqCn0yxgS5BJV6gIpRnuylrcfjmqucN1Zby8HX
mEgNKnIh6ytlSjjLWVbT4DOxU8YvRpAYS8DDkZrJnVml7/OvgAPMOHw6mGe9YfaL
CD1DLyzY+Ljk3YzOwp3nGbLwcc5oQT5SHgb9Gcj5jM/6fopXPQIDAQABo2MwYTAd
BgNVHQ4EFgQUJs/lMkPX4wJE/wcQU4HBlOOwUIkwHwYDVR0jBBgwFoAUt0hQAxeR
UNMIhuyi17Fs231ENBUwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAgQw
DQYJKoZIhvcNAQELBQADggIBAFMHLl1n4HYR6nIuu1l5oeh0LZqXMAtMGfdnXkmH
lsrsPeJnIIOtXQSOHkfeAeCN81HwXQYPQZtk1nmckIpha69Gj5FcSPnq8EBJbHR+
DPCemJ3Z54VZIyhhhdwGFs8fEVIwfQhwoW6XZ+4nrL2FLQWIiCXU6b8+J4wJu5ZM
LFgZ4dsph1jC1BqQ8Ssp6wX/C/p88AEWiKCi/5l5cmX28nhW8Wy2gO9rLinX3cWp
k3CB7YZuTwj3NSyuN2HIWf3R8tMb6RI57gH71dabqiP8EnTTvOwKmkspGnRdnwCN
JnLeMdNNbCJt05o3ehCIL9gONmTFvRnSM4DamKCygkwK5xW6pugcMJm/Exa5HJ57
wl7xIk0cSylZeBu7AE6Hghz6/EdXSHhfoxdkUeH0NWA9QtuiCBHx1jvVDTWkbI+u
rKvTlBQO19tGoopHaDgMf2TJTBO9OYHlkUzXYRfe/IKBw3bd4RobbhYIaqsGzCBE
ejZIS16/5S9pPdrmP/m2Np9R45Az8ZWGxrASO4XRv11WMD/rEsYmsBmBIjukkn7E
ncSzR9uO3s7yIrv96iW1g2Ga39eVSSJnYCVchv7nHhtqrnwiFWoPcBj9TqJ81XlY
Rmvj/tz9chXXktlao/V7YqS2iJqDJjf8riHTrZtUdb7QcLZLQCvcfagB0YAoQiQU
bEkL
-----END CERTIFICATE-----
</Certificate><Certificate format="pem">-----BEGIN CERTIFICATE-----
MIIFQTCCAymgAwIBAgIQUkZ2zFM71uQQTeGUXKASmjANBgkqhkiG9w0BAQsFADAb
MRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MB4XDTIxMDYxNjE5MjkzMloXDTMx
MDYxNDE5MjkzMlowOTEMMAoGA1UEDAwDVEVFMSkwJwYDVQQFEyA1MjE3MGJiNmMx
YmU5OThlOTFhYWMzMmFkMTZhY2M3MjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
AgoCggIBAOoGE6QMX3WmHCRdwToO6PB0wi/pXE5xzolL4m2F5KO5TykZm6iWGZwg
zPrHPa9KNREMNoDR478Em1Lg/NZ/4BqnnetRJ6AvtXhOnFvteDbgvi52anQxP0+d
z2HIODsr/dEMudEXW6yvbDQYGCiWywbIkCnvrutZaWOUh+FuBdRYfhsTOcr/WL6b
qVQ8Vd3lnII3sc4ciQAp5sEuGBsAHgTxLJTSOHj7Kzx0XxPfbFduY+iaZ02XzEr2
96QPb0aUuDUcGG0NjKyMS837h3WFZOv2oiOXbdUBnk4epbl6aaODlo3Fc2HBfn3c
AFXd8+NRZBms0I2cx8lc59juQD0xCgBdFGbTjtjNMM5D6Cxw5IZynzGUoeg27NuY
UGuKFy36ulbbJOtUeMXYajxkKxfidFSiBypQJgW+XVCwotJLDik6gE9fwdBis6fG
9NI7SDAgY/B7yCfs58h0BmvCS31w6buiaZJFMgP0HJ4eWf3OMEhmI9rzv/Mxne31
5zXCpXvDmFuQ4bM/8CrZwpcPuXXYxrPrEf5Y+B2PBTi0mZEZGomaQlsFm3rnRr7o
wGgktq4WZ5FJflKmxQ2RDU9ARkYnlPNLsy2c3WvhPJQVlOzEQr1GAdIIJZhmj8ic
yYRBWQbx1KqvIylg2vjB3bLkLaYbmQooTx7PvyfjZnNEuFbATQTrAgMBAAGjYzBh
MB0GA1UdDgQWBBS3SFADF5FQ0wiG7KLXsWzbfUQ0FTAfBgNVHSMEGDAWgBQ2YeEA
fIgFCVGLRGxH/xpMyepPEjAPBgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIC
BDANBgkqhkiG9w0BAQsFAAOCAgEAoB1Nfs/Vc7jXb5JzCkk+3sharcxUT68S/s1w
tez7kEU7ZvucoAC0mSkc8WaeyEU1ol87q5ft/phAYoonDw6YP14jog8gStknM2uY
KL8waSWHZv6BgSahUFC9XpsxrGjIUClQENFa/RoQPCW4A1eD2lhaBYsawxaIa15k
x0ZQRYVThCmfUi6aXlFHlACbyN6nwbE9wqgqnL9KzTeITBkxLwn8q47UODtZxOlU
fUczSnahp+/jLRI3lt72hYdnZ/LQeySodrNPy1aPKdEuot0K/vI5saeag3KILAHY
3Y1WR+JgBQo/7H3tlBDWed/W3c+sldvNgHgV3k4RgodGRYXLvKDPya681w71U7vt
vRvHPyLAKgrY60/0zzckLuXUgCFSAeQGo6W7bnpc3SxY/SZxKYWypclT97yN5l4+
//C/Ezg3avtwGp61XvBInmGbWXQl2fG4bVlNLVm2VasZeIDoqL0Xexybu9G4MTCO
hY3vwHfG3Xkrdw3T8K+uhlFWDD6DhxUCZE8X6OEEgU1A/QcAInnkOu3dztv3OF90
SH5InJyIZqyh5BWwuii3rjdklp/+0ZSV+EASvNOalsZeyyU4sf402SWHClKep/oe
0AxkiFGbCQLE31dLCYePo+DaAikTozxPAjAGlPzUQe6Q0vRN1iYSFv6ktGob/mWg
zWRSdfo=
-----END CERTIFICATE-----
</Certificate><Certificate format="pem">-----BEGIN CERTIFICATE-----
MIIFHDCCAwSgAwIBAgIJANUP8luj8tazMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNV
BAUTEGY5MjAwOWU4NTNiNmIwNDUwHhcNMTkxMTIyMjAzNzU4WhcNMzQxMTE4MjAz
NzU4WjAbMRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MIICIjANBgkqhkiG9w0B
AQEFAAOCAg8AMIICCgKCAgEAr7bHgiuxpwHsK7Qui8xUFmOr75gvMsd/dTEDDJdS
Sxtf6An7xyqpRR90PL2abxM1dEqlXnf2tqw1Ne4Xwl5jlRfdnJLmN0pTy/4lj4/7
tv0Sk3iiKkypnEUtR6WfMgH0QZfKHM1+di+y9TFRtv6y//0rb+T+W8a9nsNL/ggj
nar86461qO0rOs2cXjp3kOG1FEJ5MVmFmBGtnrKpa73XpXyTqRxB/M0n1n/W9nGq
C4FSYa04T6N5RIZGBN2z2MT5IKGbFlbC8UrW0DxW7AYImQQcHtGl/m00QLVWutHQ
oVJYnFPlXTcHYvASLu+RhhsbDmxMgJJ0mcDpvsC4PjvB+TxywElgS70vE0XmLD+O
JtvsBslHZvPBKCOdT0MS+tgSOIfga+z1Z1g7+DVagf7quvmag8jfPioyKvxnK/Eg
sTUVi2ghzq8wm27ud/mIM7AY2qEORR8Go3TVB4HzWQgpZrt3i5MIlCaY504LzSRi
igHCzAPlHws+W0rB5N+er5/2pJKnfBSDiCiFAVtCLOZ7gLiMm0jhO2B6tUXHI/+M
RPjy02i59lINMRRev56GKtcd9qO/0kUJWdZTdA2XoS82ixPvZtXQpUpuL12ab+9E
aDK8Z4RHJYYfCT3Q5vNAXaiWQ+8PTWm2QgBR/bkwSWc+NpUFgNPN9PvQi8WEg5Um
AGMCAwEAAaNjMGEwHQYDVR0OBBYEFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMB8GA1Ud
IwQYMBaAFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMA8GA1UdEwEB/wQFMAMBAf8wDgYD
VR0PAQH/BAQDAgIEMA0GCSqGSIb3DQEBCwUAA4ICAQBOMaBc8oumXb2voc7XCWnu
XKhBBK3e2KMGz39t7lA3XXRe2ZLLAkLM5y3J7tURkf5a1SutfdOyXAmeE6SRo83U
h6WszodmMkxK5GM4JGrnt4pBisu5igXEydaW7qq2CdC6DOGjG+mEkN8/TA6p3cno
L/sPyz6evdjLlSeJ8rFBH6xWyIZCbrcpYEJzXaUOEaxxXxgYz5/cTiVKN2M1G2ok
QBUIYSY6bjEL4aUN5cfo7ogP3UvliEo3Eo0YgwuzR2v0KR6C1cZqZJSTnghIC/vA
D32KdNQ+c3N+vl2OTsUVMC1GiWkngNx1OO1+kXW+YTnnTUOtOIswUP/Vqd5SYgAI
mMAfY8U9/iIgkQj6T2W6FsScy94IN9fFhE1UtzmLoBIuUFsVXJMTz+Jucth+IqoW
Fua9v1R93/k98p41pjtFX+H8DslVgfP097vju4KDlqN64xV1grw3ZLl4CiOe/A91
oeLm2UHOq6wn3esB4r2EIQKb6jTVGu5sYCcdWpXr0AUVqcABPdgL+H7qJguBw09o
jm6xNIrw2OocrDKsudk/okr/AwqEyPKw9WnMlQgLIKw1rODG2NvU9oR3GVGdMkUB
ZutL8VuFkERQGt6vQ2OCw0sV47VMkuYbacK/xyZFiRcrPJPb41zgbQj9XAEyLKCH
ex0SdDrx+tWUDqG8At2JHA==
-----END CERTIFICATE-----
</Certificate></CertificateChain></Key></Keybox>
</AndroidAttestation>
'
Old_keyxml="/data/adb/tricky_store/keybox.xml"

for Zip1 in "$MODULE_DIR"/*.zip; do
    if [ -f "$Zip1" ]; then
        echo "正在刷入模块: $Zip1"
        apd module install "$Zip1"
        if [ $? -eq 0 ]; then
            echo "模块 $Zip1 刷入成功。"
        else
            echo "模块 $Zip1 刷入失败。"
        fi
    fi
    sleep 0.3
done
echo "$Keyxml" > "$Old_keyxml"

mkdir -p /data/adb/tricky_store
pm list packages -3 | sed 's/package://g' > /data/adb/tricky_store/target.txt
cat /data/adb/tricky_store/target.txt


vbmeta_digest=$(getprop ro.boot.vbmeta.digest 2>/dev/null)

# 检查是否成功获取哈希值
if [ -z "$vbmeta_digest" ]; then
    echo -e "无法直接从当前设备获取哈希值！"
    echo -e "\n手动获取哈希值的方法：\n①、挂VPN \n②、打开密钥认证1.6.1 \n③、找到verifiedBootHash \n④、复制verifiedBootHash值，并粘贴到脚本中"
    
    echo -n -e "请手动输入哈希值: "
    read -r vbmeta_digest
fi

# 清理输入，删除所有非字母和数字的字符
cleaned_digest=$(echo "$vbmeta_digest" | tr -d '[:punct:]' | tr -d ' ' | tr -d '\n' | tr -d '\r')

# 检查清理后的输入是否为空
if [ -z "$cleaned_digest" ]; then
    echo -e "错误：输入的哈希值不能为空！"
    exit 1
fi

# 转换为大写
cleaned_digest_upper=$(echo "$cleaned_digest" | tr '[:lower:]' '[:upper:]')

# 检查清理后的字符长度是否为64
if [ "${#cleaned_digest_upper}" -ne 64 ]; then
    echo -e "错误：输入的哈希值必须包含 64 个字符！当前字符数为：${#cleaned_digest_upper}"
    exit 1
fi

# 打印当前设备哈希值
echo -e "\n当前设备哈希值为：$cleaned_digest_upper\n"

# 创建目录和属性文件
PROP_FILE_PATH="/data/adb/modules/haxizhi"
SERVICE_FILE="$PROP_FILE_PATH/service.sh"
MODULE_FILE="$PROP_FILE_PATH/module.prop"

mkdir -p "$PROP_FILE_PATH"
{
    echo "#!/system/bin/sh"
    echo "resetprop -n ro.boot.vbmeta.digest $cleaned_digest_upper"
} > "$SERVICE_FILE"

{
    echo "id=haxizhi"
    echo "name=重置哈希值"
    echo "version=V0204"
    echo "versionCode=20250204"
    echo "author=zygote133"
    echo "description=此模块由 zygote133 制作的 一键隐藏环境 自动生成"
} > "$MODULE_FILE"

echo -e "已自动创建 开机自动重置哈希值 模块"
echo -e "接下来会自动重启!!!\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启"
sleep 3
echo "第六步执行完毕!现在开始最终清理..."
sleep 0.5
rm -rfv "/data/local/tmp/shizuku"
rm -rfv "/data/local/tmp/shizuku_starter"
rm -rfv "/storage/emulated/0/TWRP"
rm -rfv "/data/local/tmp/shizuku/"
rm -rfv "/data/adb/modules/zn_magisk_compat/"
rm -rfv "$zygote"
sleep 0.5
rm -f "$0"
reboot