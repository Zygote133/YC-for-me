tmp="/data/local/tmp"
APK_DIR="/storage/emulated/0/Zygote133/安装包"
zygote="/storage/emulated/0/Zygote133"
selinux_status=$(getenforce)

if [ "$selinux_status" == "Enforcing" ];then
setenforce 0
echo -e "SELinux 已临时关闭"
else
echo -e "SELinux 临时关闭失败"
fi

for apk in "$APK_DIR"/*.apk; do
    if [ -f "$apk" ]; then
        cp "$apk" "$tmp/"
    else
        echo "$apk 不存在或者不是文件"
    fi
done

for apk in "$tmp"/*.apk; do
    if [ -f "$apk" ]; then
        echo "正在安装: $apk"
        if pm install "$apk"; then
            echo "$apk 安装成功"
        else
            echo "$apk 安装失败"
        fi
        rm "$apk"
    else
        echo "$apk 不存在或者不是文件"
    fi
done

sleep 5